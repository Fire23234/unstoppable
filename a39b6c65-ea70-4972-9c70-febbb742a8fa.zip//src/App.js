import React from "react";
import HabitTracker from "./HabitTracker";

export default function App() {
  return (
    <div className="App">
      <h1>Beast Mode Tracker</h1>
      <HabitTracker />
    </div>
  );
}
