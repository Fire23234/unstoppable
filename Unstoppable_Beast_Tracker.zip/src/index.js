import React from "react";
import ReactDOM from "react-dom/client";
import HabitTracker from "./HabitTracker";
import "./index.css";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <HabitTracker />
  </React.StrictMode>
);